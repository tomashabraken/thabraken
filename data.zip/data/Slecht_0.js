var json_Slecht_0 = {
"type": "FeatureCollection",
"name": "Slecht_0",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Adres": "Dijckpotingen  9", "Plaats": "Vierpolders", "Regio": "Voorne-Putten", "Cijfer": 3.5, "Beleving": "Slecht" }, "geometry": { "type": "Point", "coordinates": [ 4.179510226, 51.87886286 ] } },
{ "type": "Feature", "properties": { "Adres": "s-Heer Hendrikskinderenstraat 48 D", "Plaats": "Goes", "Regio": "Zeeland", "Cijfer": 2.5, "Beleving": "Slecht" }, "geometry": { "type": "Point", "coordinates": [ 3.887048247, 51.50734665 ] } }
]
}
