var json_Slecht_4 = {
"type": "FeatureCollection",
"name": "Slecht_4",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Adres": "Hollands Diep 19", "Plaats": "Middelharnis", "Regio": "Goeree-Overflakkee", "Cijfer": 3.3, "Kwaliteit": "Slecht" }, "geometry": { "type": "Point", "coordinates": [ 4.179603839, 51.76257551 ] } }
]
}
