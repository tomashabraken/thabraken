var json_Goed_7 = {
"type": "FeatureCollection",
"name": "Goed_7",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Adres": "P,J. Bliekstraat  2f", "Plaats": "Spijkenisse", "Regio": "Voorne-Putten", "Cijfer": 8.0, "Kwaliteit": "Goed" }, "geometry": { "type": "Point", "coordinates": [ 4.332023211, 51.84489269 ] } },
{ "type": "Feature", "properties": { "Adres": "Sluispoort 6 ", "Plaats": "Oudenbosch", "Regio": "Brabant", "Cijfer": 8.0, "Kwaliteit": "Goed" }, "geometry": { "type": "Point", "coordinates": [ 4.52473701, 51.59138954 ] } },
{ "type": "Feature", "properties": { "Adres": "Sluispoort 2", "Plaats": "Oudenbosch", "Regio": "Brabant", "Cijfer": 8.0, "Kwaliteit": "Goed" }, "geometry": { "type": "Point", "coordinates": [ 4.524641472, 51.59135401 ] } },
{ "type": "Feature", "properties": { "Adres": "Sluispoort 4a", "Plaats": "Oudenbosch", "Regio": "Brabant", "Cijfer": 8.0, "Kwaliteit": "Goed" }, "geometry": { "type": "Point", "coordinates": [ 4.524716266, 51.59138227 ] } },
{ "type": "Feature", "properties": { "Adres": "Sluispoort 5a", "Plaats": "Oudenbosch", "Regio": "Brabant", "Cijfer": 8.0, "Kwaliteit": "Goed" }, "geometry": { "type": "Point", "coordinates": [ 4.524687246, 51.59152039 ] } },
{ "type": "Feature", "properties": { "Adres": "Haringvliet 21", "Plaats": "Middelharnis", "Regio": "Goeree-Overflakkee", "Cijfer": 8.0, "Kwaliteit": "Goed" }, "geometry": { "type": "Point", "coordinates": [ 4.178370048, 51.76267131 ] } },
{ "type": "Feature", "properties": { "Adres": "Appelstraat 121", "Plaats": "Goes", "Regio": "Zeeland", "Cijfer": 8.0, "Kwaliteit": "Goed" }, "geometry": { "type": "Point", "coordinates": [ 3.890906702, 51.4944616 ] } }
]
}
